/*
===============================================================================
 Script Name:      sales_orders_analysis.sql
 Description:      Sales order query examples including dropship and backorder
===============================================================================
*/

-- Sales Orders (E-Merge)
SELECT 
    CONCAT(SOOrders.SONumber, ' shipping to ', SOOrders.ShipToCity, ', ', 
           SOOrders.ShipToState, ', had Dropship Warehouse ', SOOrders.Description) AS DropshipAdjustment
FROM SOOrders
WHERE SOOrders.CreateDate > '2024-09-01'
  AND SOOrders.Description LIKE '%changed to%'
  AND SOOrders.Description LIKE '% AG%'
ORDER BY SOOrders.CreateDate;
