/*
===============================================================================
 Script Name:      backorder_zero_inventory.sql
 Description:      Identifies backordered items and items with zero quantities
===============================================================================
*/

SELECT  
    so.SONumber,
    so.QuantityBackOrdered,
    sod.Description,
    sod.ItemID,
    sot.OrderType
FROM dbo.SOOrders so
JOIN dbo.SOOrderDetails sod ON so.SOID = sod.SOID
JOIN dbo.SOOrderTypes sot ON so.OrderTypeID = sot.OrderTypeID
WHERE so.CreateDate > '2024-02-17'
  AND so.QuantityBackOrdered > 0
  AND sot.Description LIKE '%Supply Order%'
ORDER BY so.SONumber, sod.ItemID;
