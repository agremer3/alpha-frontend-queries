/*
===============================================================================
 Script Name:      table_and_column_search.sql
 Description:      Utilities for searching SQL Server metadata tables
===============================================================================
*/

-- Search for tables by name pattern
SELECT name AS TableName 
FROM sys.tables 
WHERE name LIKE '%CustomProperties%';

-- Search for columns by name pattern
SELECT  
    TABLE_SCHEMA, 
    TABLE_NAME, 
    COLUMN_NAME, 
    DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE COLUMN_NAME LIKE '%Cost%';
