/*
===============================================================================
 Script Name:      custom_properties_accessories.sql
 Description:      Identifies items with “Accessories” needing normalization
===============================================================================
*/

-- (1/2) Custom Property Attribute Definitions
SELECT 
    s.AttributeName, 
    s.ShAttributeID 
FROM dbo.ShAttributes s 
WHERE s.ShAttributeID IN ('2167','2168','2169')
ORDER BY s.AttributeName;

-- (2/2) Finding “Accessories” that should be changed to “Accessory”
SELECT 
    i.Item,
    i.Description,
    icp.ShAttributeID,
    CASE icp.ShAttributeID
        WHEN 2167 THEN 'SF Category'
        WHEN 2168 THEN 'SF ProductType'
        WHEN 2169 THEN 'SF RecordType'
        ELSE 'Other'
    END AS [Custom Property],
    icp.TextVal,
    icp.CreatorID,
    icp.CreateDate
FROM dbo.ICItems AS i
LEFT JOIN dbo.ICItemCustomProperties AS icp ON i.ItemID = icp.ItemID
WHERE icp.TextVal IN ('Accessories')
ORDER BY [Custom Property];
